//
//  CountryPicker.swift
//  CountryPicker_SwiftUI
//
//  Created by Maneet@MLL on 26/11/25.
//

import SwiftUI

struct CountryCodePicker: View {
    
    @State var countries: [CountryData] = []
    @State var searchCountry: String = ""
    
    @Environment(\.dismiss) private var dismiss
    
    public var onSelect: (CountryData) -> Void
    
    public init(onSelect: @escaping (CountryData) -> Void) {
        self.onSelect = onSelect
    }
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Spacer()
                Button(action: {
                    dismiss()
                }, label: {
                    Image(systemName: "multiply.circle.fill")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundStyle(.gray)
                }).buttonStyle(.plain)
            }
            .padding()
            
            TextField("Search Country", text: $searchCountry)
                .padding(10)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .padding(.horizontal)
                .padding(.bottom)

            List(filteredCountries) { item in
                Button {
                    onSelect(item)
                    dismiss()
                } label: {
                    HStack(spacing: 14) {
                        Text(item.flag)
                            .font(.system(size: 28))
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.name)
                                .font(.system(size: 16))
                                .foregroundStyle(.primary)
                            Text(item.dial_code)
                                .font(.system(size: 14))
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                    .contentShape(Rectangle()) // Make entire row tappable
                }
                .buttonStyle(.plain)
            }
            .listStyle(.plain)
        }
        .onAppear {
            loadData()
        }
    }
    
    private var filteredCountries: [CountryData] {
        if searchCountry.isEmpty { return countries }
        return countries.filter {
            $0.name.lowercased().contains(searchCountry.lowercased()) ||
            $0.dial_code.contains(searchCountry)
        }
    }
    
    private func loadData() {
        guard let codeData = Bundle.module.url(forResource: "countryCode", withExtension: "json") else {
            print("Country Code data not available")
            return
        }
        
        do {
            let data = try Data(contentsOf: codeData)
            let model = try JSONDecoder().decode([CountryData].self, from: data)
            self.countries = model
        } catch {
            print("Failed to decode JSON:", error)
        }
    }
}
